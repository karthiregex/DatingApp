﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.Entities;

namespace DatingApp.BusinessLayer.Interfaces
{
    public interface IUserService
    {
        Task<bool> CreateNewUser(User user);

        Task<User> VerifyUser(string UserName, string Password);

        Task<string> ChangePassword(string UserName, string NewPassword);

        Task<string> SuspendUser(string UserName, UserStatus userStatus);

        Task<bool> AddProfile(Profile profile);

        Task<IEnumerable<User>> ListOfMembers();
    }
}
