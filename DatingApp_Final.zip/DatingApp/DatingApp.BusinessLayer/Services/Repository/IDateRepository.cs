﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.Entities;

namespace DatingApp.BusinessLayer.Services.Repository
{
    public interface IDateRepository
    {
        Task<DateDetail> GetDateDetailById(long dateId);
        Task<DateDetail> GetDateDetailByUser(string RequestSenderName);
        Task<DateDetail> GetDateDetailByDate(DateTime DateOfRequest);
        Task<bool> AddDateDetail(DateDetail appointment);
        Task<DateDetail> UpdateDateDetail(DateDetail appointment);
        Task<DateDetail> CancelDateDetail(DateDetail appointment);
        Task<String> SendRequest(DateDetail user);
    }
}
