﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.DataLayer;
using DatingApp.Entities;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace DatingApp.BusinessLayer.Services.Repository
{
    public class UserRepository : IUserRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in UserRepository constructor
        /// </summary>
        private readonly DatingAppDbContext _datingContext;
        public UserRepository(DatingAppDbContext datingDbContext)
        {
            _datingContext = datingDbContext;
        }

        /// <summary>
        /// Able to add a new User Profile
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<bool> AddProfile(Profile profile)
        {
            try
            {
                await _datingContext.Profiles.AddAsync(profile);
                await _datingContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// An existing user can change the password of their account
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="NewPassword"></param>
        /// <returns></returns>
        public async Task<string> ChangePassword(string UserName, string NewPassword)
        {
            try
            {
                var result = await _datingContext.UserDetails
                    .FirstOrDefaultAsync(h => h.UserName.Equals(UserName));
                result.UserName = UserName;
                result.Password = NewPassword;
                _datingContext.Update(result);
                await _datingContext.SaveChangesAsync();
                return $"Password changed Successfully";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used to create a new User
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<bool> CreateNewUser(User user)
        {
            try
            {
                await _datingContext.UserDetails.AddAsync(user);
                await _datingContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used display all the members in the application
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<User>> ListOfMembers()
        {
            try
            {
                var result = await _datingContext.UserDetails
                    .OrderBy(x => x.UserId).Take(10).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used to suspend an Existing User
        /// </summary>
        /// <param name="user"></param>
        /// <param name="userStatus"></param>
        /// <returns></returns>
        public async Task<string> SuspendUser(string UserName, UserStatus userStatus)
        {
            try
            {
                var result = await _datingContext.UserDetails
                    .FirstOrDefaultAsync(h => h.UserName.Equals(UserName));

                result.UserStatus = userStatus;
                await _datingContext.SaveChangesAsync();
                return $"Status Updated, new Status { userStatus}";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// THe below Method used to verify an Existing User
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        public async Task<User> VerifyUser(string UserName, string Password)
        {
            try
            {
                var result = await _datingContext.UserDetails
                    .FirstOrDefaultAsync(h => h.UserName.Equals(UserName) && h.Password.Equals(Password));

                if (result != null)
                {
                    return result;
                }
                return null;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
