﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.Entities;

namespace DatingApp.BusinessLayer.Services.Repository
{
    public interface IUserRepository
    {
        Task<bool> CreateNewUser(User user);

        Task<User> VerifyUser(string UserName, string Password);

        Task<bool> AddProfile(Profile profile);

        Task<IEnumerable<User>> ListOfMembers();

        Task<string> ChangePassword(string UserName, string NewPassword);

        Task<string> SuspendUser(string UserName, UserStatus userStatus);

    }
}
