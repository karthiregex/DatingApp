﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DatingApp.Entities
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        [Required]
        [Display(Name = "UserName")]
        public string UserName { get; set; }
        [Required]
        [Display(Name = "Password")]
        public string Password { get; set; }
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }
        [Required]
        [Display(Name = "MobileNumber")]
        public long MobileNumber { get; set; }
        [Required]
        [Display(Name = "UserType")]
        public UserType UserType { get; set; }
        [Required]
        [Display(Name = "UserStatus")]
        public UserStatus UserStatus { get; set; }
    }
}
