﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatingApp.Entities
{
    public class Response
    {
        public string Status { get; set; }
        public string Message { get; set; }
    }
}
