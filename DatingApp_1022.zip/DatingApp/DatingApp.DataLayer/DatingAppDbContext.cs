﻿using DatingApp.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DatingApp.DataLayer
{
    public class DatingAppDbContext : IdentityDbContext<UserMaster>
    {
        public DatingAppDbContext(DbContextOptions<DatingAppDbContext> options) : base(options)
        {

        }
        /// <summary>
        /// Seed and create DbSet for all Dating App classes
        /// </summary>
        public DbSet<Profile> Profiles { get; set; }
        public DbSet<DateDetail> DateDetails { get; set; }
        public DbSet<User> UserDetails { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Profile>().HasKey(x => x.ProfileId);
            builder.Entity<User>().HasKey(x => x.UserId);
            builder.Entity<DateDetail>().HasKey(x => x.DateId);
            base.OnModelCreating(builder);
        }
    }
}
