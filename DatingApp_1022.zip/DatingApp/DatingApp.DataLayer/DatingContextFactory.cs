﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System;
using System.Collections.Generic;
using System.Text;

namespace DatingApp.DataLayer
{
    public class DatingContextFactory : IDesignTimeDbContextFactory<DatingAppDbContext>
    {
        public DatingAppDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<DatingAppDbContext>();
            optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=DatingDB;Integrated Security=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            return new DatingAppDbContext(optionsBuilder.Options);
        }
    }
}
