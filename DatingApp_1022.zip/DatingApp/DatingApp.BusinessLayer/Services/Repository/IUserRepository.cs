﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.Entities;

namespace DatingApp.BusinessLayer.Services.Repository
{
    public interface IUserRepository
    {
        Task<User> CreateNewUser(User user);

        Task<User> VerifyUser(string UserName, string Password);

        Task<Profile> AddProfile(Profile profile);

        Task<IEnumerable<User>> ListOfMembers();

        Task<string> ChangePassword(string UserName, string NewPassword);

        Task<string> SuspendUser(string UserName, UserStatus userStatus);

    }
}
