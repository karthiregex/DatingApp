﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.DataLayer;
using DatingApp.Entities;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace DatingApp.BusinessLayer.Services.Repository
{
    public class DateRepository : IDateRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in UserRepository constructor
        /// </summary>
        private readonly DatingAppDbContext _datingContext;
        public DateRepository(DatingAppDbContext datingDbContext)
        {
            _datingContext = datingDbContext;
        }

        public Task<DateDetail> AddDateDetail(DateDetail appointment)
        {
            throw new NotImplementedException();
        }

        public Task<DateDetail> CancelDateDetail(DateDetail appointment)
        {
            throw new NotImplementedException();
        }

        public Task<DateDetail> GetDateDetailByDate(DateTime DateOfRequest)
        {
            throw new NotImplementedException();
        }

        public Task<DateDetail> GetDateDetailById(long dateId)
        {
            throw new NotImplementedException();
        }

        public Task<DateDetail> GetDateDetailByUser(string RequestSenderName)
        {
            throw new NotImplementedException();
        }

        public Task<string> SendRequest(DateDetail user)
        {
            throw new NotImplementedException();
        }

        public Task<DateDetail> UpdateDateDetail(DateDetail appointment)
        {
            throw new NotImplementedException();
        }
    }
}
