﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.DataLayer;
using DatingApp.Entities;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace DatingApp.BusinessLayer.Services.Repository
{
    public class UserRepository : IUserRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in UserRepository constructor
        /// </summary>
        private readonly DatingAppDbContext _datingContext;
        public UserRepository(DatingAppDbContext datingDbContext)
        {
            _datingContext = datingDbContext;
        }

        public Task<Profile> AddProfile(Profile profile)
        {
            throw new NotImplementedException();
        }

        public Task<string> ChangePassword(string UserName, string NewPassword)
        {
            throw new NotImplementedException();
        }

        public Task<User> CreateNewUser(User user)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<User>> ListOfMembers()
        {
            throw new NotImplementedException();
        }

        public Task<string> SuspendUser(string UserName, UserStatus userStatus)
        {
            throw new NotImplementedException();
        }

        public Task<User> VerifyUser(string UserName, string Password)
        {
            throw new NotImplementedException();
        }
    }
}
