﻿using System;
using System.Threading.Tasks;
using DatingApp.BusinessLayer.Interfaces;
using DatingApp.BusinessLayer.Services.Repository;
using DatingApp.Entities;

namespace DatingApp.BusinessLayer.Services
{
    public class DateService : IDateService
    {

        private readonly IDateRepository _dateRepository;
        /// <summary>
        /// </summary>
        public DateService(IDateRepository dateRepository)
        {
            _dateRepository = dateRepository;
        }

        public Task<DateDetail> AddDateDetail(DateDetail appointment)
        {
            throw new NotImplementedException();
        }

        public Task<DateDetail> CancelDateDetail(DateDetail appointment)
        {
            throw new NotImplementedException();
        }

        public Task<DateDetail> GetDateDetailByDate(DateTime DateOfRequest)
        {
            throw new NotImplementedException();
        }

        public Task<DateDetail> GetDateDetailById(long dateId)
        {
            throw new NotImplementedException();
        }

        public Task<DateDetail> GetDateDetailByUser(string RequestSenderName)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Call user repository method to send request
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<string> SendRequest(DateDetail user)
        {
            try
            {
                var result = await _dateRepository.SendRequest(user);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<DateDetail> UpdateDateDetail(DateDetail appointment)
        {
            throw new NotImplementedException();
        }
    }
}
