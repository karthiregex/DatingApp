﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.BusinessLayer.Interfaces;
using DatingApp.BusinessLayer.Services.Repository;
using DatingApp.Entities;

namespace DatingApp.BusinessLayer.Services
{
    public class UserService : IUserService
    {
        /// <summary>
        /// Creating instance/field of IClientReviewRepository and injecting into ClientReviewServices Constructor
        /// </summary>
        private readonly IUserRepository _userRepository;
        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public Task<Profile> AddProfile(Profile profile)
        {
            throw new NotImplementedException();
        }

        public Task<string> ChangePassword(string UserName, string NewPassword)
        {
            throw new NotImplementedException();
        }

        public Task<User> CreateNewUser(User user)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<User>> ListOfMembers()
        {
            throw new NotImplementedException();
        }

        public Task<string> SuspendUser(string UserName, UserStatus userStatus)
        {
            throw new NotImplementedException();
        }

        public Task<User> VerifyUser(string UserName, string Password)
        {
            throw new NotImplementedException();
        }
    }
}
