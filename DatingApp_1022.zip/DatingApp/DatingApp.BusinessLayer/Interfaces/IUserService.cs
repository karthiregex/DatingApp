﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DatingApp.Entities;

namespace DatingApp.BusinessLayer.Interfaces
{
    public interface IUserService
    {
        Task<User> CreateNewUser(User user);

        Task<User> VerifyUser(string UserName, string Password);

        Task<string> ChangePassword(string UserName, string NewPassword);

        Task<string> SuspendUser(string UserName, UserStatus userStatus);

        Task<Profile> AddProfile(Profile profile);

        Task<IEnumerable<User>> ListOfMembers();
    }
}
